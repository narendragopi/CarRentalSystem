// import logo from './logo.svg';

import { NotificationContainer } from 'react-notifications';
import { Provider } from 'react-redux';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from 'react-router-dom';

import './App.css';
import Cars from './Components/CarOperation/Cars';
import Customers from './Components/CustomerOparation';
import Dashboard from './Components/Dashboard';
import Login from './Components/Login';
import NotFoundPage from './Components/NotFoundPage';
import Register from './Components/Register';
import Test from './Components/Test/Test';
import PrivateRoute from './Helpers/PrivateRoute';
import Store from './Redux/store';
import Rentals from './Components/RentalOperation';
import Returns from './Components/Return/return';


function App() {
  return (
    <Provider store={Store}>
      <div className="App">
       <RoutesMain /> 
        {/* <Test/> */}
        <NotificationContainer />
      </div>
    </Provider>
  );
}

// const RoutesMain = () => (<Router>
//   <div className="App">
//     <ul className="App-header">
//     </ul>
//     <Routes>
//       <Route path="*" element={<NotFoundPage/>} />
//       <Route exact path='login' element={< Login />}></Route>
//       <Route exact path='register' element={< Register />}></Route>
//       <Route exact path='dashboard' element={<PrivateRoute><Dashboard />  </PrivateRoute>}>
//         <Route exact path='cars' element={<PrivateRoute><Cars /> </PrivateRoute>}></Route>
//         <Route exact path='' element={<PrivateRoute><Cars /> </PrivateRoute>}></Route>
//         <Route exact path='customers' element={<PrivateRoute><Customers /> </PrivateRoute>}></Route>
//         <Route exact path='rentals' element={<PrivateRoute><Rentals/> </PrivateRoute>}></Route>
//         <Route exact path='returns' element={<PrivateRoute><Returns/> </PrivateRoute>}></Route>
//       </Route>
//     </Routes>
//   </div>
// </Router>)
let auth =  JSON.parse(localStorage.getItem('token'));


const RoutesMain = () => (<Router>
  <div className="App">
    <ul className="App-header">
    </ul>
    <Routes>
      <Route path="*" element={<Login/>} />
      <Route exact path='login' element={< Login />}></Route>
      <Route exact path='register' element={< Register />}></Route>
      <Route exact path='dashboard' element={<PrivateRoute><Dashboard />  </PrivateRoute>}>
        <Route path="*" element={<NotFoundPage/>} />
        <Route exact path='cars' element={<PrivateRoute><Cars /> </PrivateRoute>}></Route>
        <Route exact path='' element={<PrivateRoute><Cars /> </PrivateRoute>}></Route>
        <Route exact path='customers' element={<PrivateRoute><Customers /> </PrivateRoute>}></Route>
        <Route exact path='rentals' element={<PrivateRoute><Rentals/> </PrivateRoute>}></Route>
        <Route exact path='returns' element={<PrivateRoute><Returns/> </PrivateRoute>}></Route>
      </Route>
    </Routes>
  </div>
</Router>)
export default App;
