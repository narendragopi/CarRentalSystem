import axios from "axios";

export const RentalService ={

    GetRental:async(pageSize = 10,pageNumber =1,query='') =>{
        return await  axios.get(`http://localhost:5001/rentals?_limit=${pageSize}&_page=${pageNumber}&_order=desc&_sort=id&_expand=cars&_expand=customers&q=${query}`);
    },
    AddRental:async (rental) => {
       return await axios.post(`http://localhost:5001/rentals`,rental);
    },
    UpdateRental: async (rental) => {
        return await axios.put(`http://localhost:5001/rentals/${rental.id}`,rental)
    },
    DeleteRental:async (id) => {
        return await axios.delete(`http://localhost:5001/rentals/${id}`);
    }
}