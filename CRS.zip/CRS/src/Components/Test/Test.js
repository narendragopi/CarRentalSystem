import axios from 'axios'
import { Field, Formik } from 'formik';
import { useState, useEffect } from 'react'
import Select from 'react-select'
import { SelectField } from '../HOCModal/SelectField';

import { useDispatch, useSelector } from 'react-redux';
import { GetCars } from '../../Redux/actions/CarAction';


const Test = () => {
    const [data, setdata] = useState([]);
    const getsome = async () => {
        await axios.get(`http://localhost:5001/cars`).then(s => {
            setdata(s.data);
        });

    }

    useEffect(() => {
        getsome();
        console.log(data);
        return () => {
        }
    }, [0]);

    return <div className='container'>
        <div className='row'>
            {data.map(s => {
                <div className='col-4'>
                    <img src='https://cdni.autocarindia.com/utils/imageresizer.ashx?n=http://cms.haymarketindia.net/model/uploads/modelimages/Volvo-S60-130220211541.jpg&w=872&h=578&q=75&c=1' />
                    <h1>hello world</h1>
                </div>
            })}

        </div>
    </div>
}

export default Test;