import NotFoundImg from '.././../page.jpg' 

const mystyle = {
 width: "280px",
 backgroundColor: "lightgray",
 margin:"0px 400px 0px 400px"
};

const NotFoundPage = () => {
  return(
    <div>
    <img src={NotFoundImg} alt="Page Not Found" style={mystyle}/>
    <h2 className='display-6 text-center'>Page Not Found</h2>
    </div>
  ) 
};

export default NotFoundPage;