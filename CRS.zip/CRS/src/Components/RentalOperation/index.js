import Rentals from './Rentals';

export default Rentals;