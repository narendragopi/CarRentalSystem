import { APIConstants } from "../constants/APIConstants";
import { NotificationTypes } from "../constants/NotificationConstants";
import { ReturnService } from './../../Services/ReturnService';


export const GetReturns= (pageSize = 10, pageNumber = 1,query = '') => async (dispatch) => {

    await ReturnService.GetReturn(pageSize, pageNumber,query).then(s => {
        dispatch({
            type: APIConstants.RETURNS.GET_RETURNS,
            payload: {
                list: s.data,
                pageSize: pageSize,
                pageNumber: pageNumber,
                count: parseInt(s.headers['x-total-count'])
            }
        })
    }).then(s => {
        console.log(s);
    })
}


export const AddReturns = (returnd, func) => async (dispatch) => {

    await ReturnService.AddReturn(returnd).then(async s => {
        await ReturnService.GetReturn().then(async v => {
            var count = parseInt(v.headers['x-total-count'])

            dispatch({
                type: APIConstants.RETURNS.ADD_RETURNS,
                payload: {
                    list: v.data,
                    pageSize: 10,
                    pageNumber: 1,
                    count: count
                }
            })
        });
    }).then(s => {
        dispatch({
            type: NotificationTypes.INFO,
            payload: 'Car Return data added successfully'
        })
    }).finally(() => func());

}

export const UpdateReturns = (returnd, func) => async (dispatch) => {


    await ReturnService.UpdateReturn(returnd).then(async s => {
        await  ReturnService.GetReturn().then(async v => {
            var count = parseInt(v.headers['x-total-count'])

            dispatch({
                type: APIConstants.RETURNS.UPDATE_RETURNS,
                payload: {
                    list: v.data,
                    pageSize: 10,
                    pageNumber: 1,
                    count: count
                }
            })
        });

    }).then(s => {
        dispatch({
            type: NotificationTypes.SUCCESS,
            payload: 'Car Returned successfully'
        })

    }).finally(() => func());

}
export const DeleteReturns = (id, func) => async (dispatch) => {

    await ReturnService.DeleteReturn(id).then(async s => {
        await ReturnService.GetReturn().then(async v => {
            var count = parseInt(v.headers['x-total-count'])

            dispatch({
                type: APIConstants.RETURNS.REMOVE_RETURNS,
                payload: {
                    list: v.data,
                    pageSize: 10,
                    pageNumber: 1,
                    count: count
                }
            })
        });

    }).then(s => {
        dispatch({
            type: NotificationTypes.INFO,
            payload: 'Car Return data deleted successfully'
        })

    }).finally(() => func());

}


