export  const NotificationTypes =  {
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
    WARNING: 'WARING',
    INFO: 'INFO'
}