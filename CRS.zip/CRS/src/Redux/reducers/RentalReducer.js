import { APIConstants } from '../constants/APIConstants';
const initialState = {

    list: [],
    pageSize: 10,
    pageNumber: 1,
    count:0
}

const RentalConstants = APIConstants.RENTALS;

function RentalReducer(rentals = initialState, action) {
    const { type, payload } = action;
    switch (type) {
        case RentalConstants.GET_RENTALS:
            return payload;

        case RentalConstants.ADD_RENTALS:
            return payload;

        case RentalConstants.UPDATE_RENTALS:
            return payload;

        case RentalConstants.REMOVE_RENTALS: 
            return payload;

        default: return rentals
    }
}

export default RentalReducer;