import { combineReducers } from "redux";
import Cars from "./reducers/CarReducers";
import Notification from './reducers/NotificationReducer';
import Customers from './reducers/CustomerReducer';
import Rentals from './reducers/RentalReducer';
import Returns from './reducers/ReturnReducer';

export default combineReducers({
   Cars,
   Customers,
   Rentals,
   Returns,
   Notification
})


