# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)

---------------------------------------
car Rental Management Work Flow Process
---------------------------------------

step 1(About Database) : initially we need to run the server project because the data will be change across the project will reflect in server project(working like backend api data).

we need to run "json-server --watch db.json --port=5001" this command on server project run in cmd then we need to take another cmd path should be same as server project path and then run "npm start" then our database is ready.

Server project in that server.js file we are implementing jsonwebtoken the roles(user,agent) in project.

step 2(About Login & Register Pages):next we are in CRMS Project by default it will take in to the login page if you want to register there will be register link we can register through register page.

step 3(About Operations) :
-->In this section we have a dashboard after login we ned to specify the information who is login thats why am giving login         information on th nav bar of the dash board.by default am showing car creation page.

-->http://localhost:3000/dashboard/sdfsdf after dashboard url u can something anything wrong path of components it will show the 404 page

-->in in every crud operation am implementing the search and pagination using fake json server parameters.

-->(CAR Operation)If Login person as a agent we are given a Create button else user we are just showing the car details only we are not  giving create button its mean user not access CRUD operations only agent can done.

--->(Customer Operation)If Login person as a agent we are not given a Create button we are just showing the customer details 
   else user we are  given a create button its mean user  access CRUD operations then agent not access CRUD operations.

-->(Rental Operation) we are not giving CRUD operation to the Customer  all crud operations given to agent only.
    here status,fee,pick date,return date(due date) key fields amount also.rent a car here..
    moreover here we have a dropdowns what ever customers and cars we created all  active cars comes these dropdowns.

-->(Return Operation)  we are not giving CRUD operation to the Customer  all crud operations given to agent only.
    here based return date(due date) in rental it will take it into the return section due date to get date date difference one day fee already we are giving in rental section based on due date to get date amount is calculated. after return a car the status of the car is must have been available. but iam trying through json server boolean VARIABLE am confusing rather than using BACKEND Api data.

->(lOGOUT Operation) click on logout redirect to login page. 

-->mostly am using redux and hooks functions because i want to maintain my state should be global. 
-->routing concept in app.js done 
-->every component folder am arrange index.js it is the main page for the folder then am redirecting to specific page through index.js 
--> am separating redux and components folders for clean separation understanding.

--->am using model,navigation alerts like professionally,using formik instead form because god looking interface,routing and index.js clean folder architecture.

am done with json server but if a take it as backend as .net api it is easy to variable reusability..

am done up to my level and am done this project.
yes am lagging some ware like authentication functionality but i have knowledge on react..json fake server is new to me almost am knowing json server fake json some where like status change issue like am lagging.


this is my project flow,,,,......