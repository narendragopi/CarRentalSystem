import Customers from './customers';
export default Customers;