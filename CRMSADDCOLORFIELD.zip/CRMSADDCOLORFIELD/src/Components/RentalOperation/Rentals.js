import axios from "axios";
import { useEffect, useState } from "react";
import Modal from 'react-modal';
import { Field, Formik } from 'formik';
import { NotificationContainer, NotificationManager } from 'react-notifications';
import { useDispatch, useSelector } from "react-redux";
import { AddRentals, DeleteRentals, GetRentals, UpdateRentals } from './../../Redux/actions/RentalAction';
import { SelectField } from '../HOCModal/SelectField';
import { SetNotificationError } from "../../Redux/actions/NotificationAction";
import { NotificationTypes } from "../../Redux/constants/NotificationConstants";


const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
    },
};


const Rentals = () => {
    const [modalIsOpen, setIsOpen] = useState(false);
    const [typeEffect, setTypeEffect] = useState('');
    const [selectedObj, setSelectedObj] = useState({});
    const [carfileter, SetCarfilter] = useState([]);
    const [customerFilter, setCustomerFilter] = useState([]);
    const [checkAvailbility, setCheckAvailiability] = useState(false);
    const [role, setRole] = useState("");

    const openModal = (type, obj) => {
        setSelectedObj(obj);
        setTypeEffect(type);
        setIsOpen(true);
    }
    const rentals = useSelector(state => state.Rentals);
    const dispatch = useDispatch();


    const afterOpenModal = () => {

    }
    const closeModal = () => {
        setIsOpen(false);
        setSelectedObj({});
    }

    useEffect(() => {
        dispatch(GetRentals());
        setRole(JSON.parse(localStorage.getItem("token")).role);
        console.log(rentals);
        return () => {
        }
    }, [0]);


    const getcars = (querystring = '') => {
        axios.get(`http://localhost:5001/cars?available=false&q=${querystring}`).then(s => {
            // var mydata = s.data.map(v => ({ value: v.id, label: `carRegNo: ${v.carRegNo} | Brand: ${v.brand} | Model: ${v.model}` }));
            var mydata = s.data.map(v => ({ value: v.id, label: `${v.carRegNo}` }));
            SetCarfilter(mydata);
        });

    }

    const CheckAvailabilityOfCar = async (startDate, EndDate, carsId, func) => {

        await axios.get(`http://localhost:5001/rentals?_expand=cars&_expand=customers&carsId=${carsId}`).then(s => {
            // var mydata = s.data.map(v => ({ value: v.id, label: `carRegNo: ${v.carRegNo} | Brand: ${v.brand} | Model: ${v.model}` }));
            var some = s.data.filter(f => f.carsId === carsId && (new Date(startDate).getTime() == new Date(f.pickDate).getTime() || new Date(f.dueDate).getTime() == new Date(EndDate).getTime()));
            setCheckAvailiability(some.length > 0);

        }).finally(() => { func() });
    }
    const getcustomers = (querystring = '') => {
        axios.get(`http://localhost:5001/customers?q=${querystring}`).then(s => {
            // var mydata = s.data.map(v => ({ value: v.id, label: `carRegNo: ${v.carRegNo} | Brand: ${v.brand} | Model: ${v.model}` }));
            var mydata = s.data.map(v => ({ value: v.id, label: `${v.customerName}` }));
            setCustomerFilter(mydata);
        });

    }
    const numPages = (count = 10) => {
        console.log(Math.ceil(rentals.count / count));
        return Math.ceil(rentals.count / count);
    }
    const prevPage = () => {

        if (rentals.pageNumber > 1) {
            var pagenum = rentals.pageNumber - 1;
            dispatch(GetRentals(10, pagenum));
        }
    }
    const nextPage = () => {
        if (rentals.pageNumber < numPages()) {
            var pageNum = rentals.pageNumber + 1;
            dispatch(GetRentals(10, pageNum));
        }
    }


    const GetSearch = (query) => {
        dispatch(GetRentals(10, 1, query));
    }

    return (<div id="carsModal">
        {role == "agent" && <button className="btn btn-mg btn-primary" onClick={() => openModal('ADD', {})}>Rental Process</button>}
        <input placeholder="Search here..." onChange={(e) => GetSearch(e.target.value)} style={{ margin: "0 0 0 700px" }} />
        <br></br>
        <hr></hr>

        <table className="table table-hover">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Car RegNo</th>
                    <th scope="col">Customer Name</th>
                    <th scope="col">Status</th>
                    <th scope="col">Rental Fee</th>
                    <th scope="col">Pick Date</th>
                    <th scope="col">Due Date</th>
                </tr>
            </thead>
            <tbody>

                {rentals.list.map((s) => (<tr>
                    <th scope="row">{s.id}</th>
                    <td>{s.cars.carRegNo}</td>
                    <td>{s.customers.customerName}</td>
                    <td>{s.status}</td>
                    <td>{s.rentalFee}</td>
                    <td>{s.pickDate}</td>
                    <td>{s.dueDate}</td>

                    {role == "agent" && <td><button className="btn btn-outline-success btn-sm" onClick={() => openModal('UPDATE', s)}>
                        <i className="fas fa-pencil-alt fa-sm"></i></button>
                        <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
                        <button className="btn btn-outline-danger btn-sm" onClick={() => openModal('DELETE', s)}>
                    <i className="fas fa-trash-alt fa-sm"></i></button></td>}

                </tr>)
                )}
            </tbody>
        </table>

        <Modal
            isOpen={modalIsOpen}
            onAfterOpen={afterOpenModal}
            onRequestClose={closeModal}
            style={customStyles}
            contentLabel="Delete Modal"
        >
            {typeEffect === 'DELETE' ?
                (
                    <div>
                        <div className="deletepopup">Are you sure! do you want to delete the car.</div>
                        <hr></hr>
                        <div>
                            <button className="btn btn-outline-primary btn-sm" onClick={() => { dispatch(DeleteRentals(selectedObj.id, () => { setIsOpen(false) })); }}>Sure</button>
                            <span>&nbsp;</span>
                            <button className="btn btn-outline-danger btn-sm" onClick={() => closeModal()}>Close</button>
                        </div>
                    </div>
                ) : <div className="rentalsModalAdd">
                    <Formik
                        initialValues={typeEffect === 'UPDATE' ?
                            {
                                id: selectedObj.id,
                                carsId: selectedObj.carsId,
                                customersId: selectedObj.customersId,
                                status: selectedObj.status,
                                rentalFee: selectedObj.rentalFee,
                                pickDate: selectedObj.pickDate,
                                dueDate: selectedObj.dueDate,
                                returned: false
                            }
                            : { carsId: '', customersId: '', status: "false", rentalFee: '', pickDate: '', dueDate: '', returned: false }}
                              validate={values => {
                            const errors = {};
                            if (!values.carsId) {
                                errors.carsId = <span style={{color:"red"}}>Required</span>;
                            }
                            if (!values.customersId) {
                                errors.customersId = <span style={{color:"red"}}>Required</span>;
                            }
                            if (!values.rentalFee) {
                                errors.rentalFee = <span style={{color:"red"}}>Required</span>;
                            }
                            if (!values.pickDate) {
                                errors.pickDate = <span style={{color:"red"}}>Required</span>;
                            }
                            if (!values.dueDate) {
                                errors.dueDate = <span style={{color:"red"}}>Required</span>;
                            }
                            return errors;
                        }}
                        onSubmit={(values, { setSubmitting }) => {
                            setTimeout(() => {
                                CheckAvailabilityOfCar(values.pickDate, values.dueDate, values.carsId, () => {
                                    if (checkAvailbility) {
                                        dispatch({
                                            type: NotificationTypes.ERROR,
                                            payload: 'Dates are not available'
                                        })
                                    }
                                    else {
                                        if (typeEffect === 'ADD') {
                                            dispatch(AddRentals(values, () => {
                                                setIsOpen(false)
                                                setSelectedObj({});
                                            }));

                                        }
                                        else {
                                            dispatch(UpdateRentals(values, () => {
                                                setIsOpen(false);
                                                setSelectedObj({});
                                            }));
                                        }
                                    }

                                })
                            }, 400);
                            setSubmitting(false);
                        }}>

                        {({
                            values,
                            errors,
                            touched,
                            handleChange,
                            handleBlur,
                            handleSubmit,
                            isSubmitting,
                        }) => (

                            <form className="carform" onSubmit={handleSubmit}>
                                <div className="form-group row">
                                    <div className="form-group col-md-6">
                                        <label>Car Id</label>
                                        <Field name={'carsId'} component={SelectField} options={carfileter} onFocus={(env) => { getcars() }} />
                                        {errors.carsId && touched.carsId && errors.carsId}
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Customer Id</label>
                                        <Field name={'customersId'} component={SelectField} options={customerFilter} onFocus={(env) => { getcustomers() }} />
                                        {errors.customersId && touched.customersId && errors.customersId}

                                    </div>
                                </div>
                                <br></br>
                                <div className="form-group row">
                                    <div className="form-group col-md-6">
                                        <label>Status</label>
                                        <input
                                            className="form-control"
                                            type="text"
                                            name="status"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.status}
                                            disabled={true}
                                        />
                                        {errors.status && touched.status && errors.status}

                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Rental Fee</label>
                                        <input
                                            className="form-control"
                                            type="text"
                                            name="rentalFee"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.rentalFee}
                                        />
                                        {errors.rentalFee && touched.rentalFee && errors.rentalFee}
                                    </div>
                                </div>
                                <br></br>
                                <div className="form-group row">
                                    <div className="form-group col-md-6">
                                        <label>Pick Date</label>
                                        <input
                                            className="form-control"
                                            type="date"
                                            name="pickDate"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.pickDate}
                                        />
                                        {errors.pickDate && touched.pickDate && errors.pickDate}

                                    </div>
                                    <div className="form-group col-md-6">
                                        <label>Due Date</label>
                                        <input
                                            className="form-control"
                                            type="date"
                                            name="dueDate"
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            value={values.dueDate}
                                        />
                                        {errors.dueDate && touched.dueDate && errors.dueDate}
                                    </div>
                                </div>
                                <br></br>
                                <div className="form-group row col-md-12 ms-0">
                                    <button className="btn btn-primary btn-sm btn-block" type="submit" disabled={isSubmitting}>
                                        Submit
                                    </button>
                                </div>
                            </form>
                        )}
                    </Formik>
                </div>}
        </Modal>

        <div className="table-bottom">
            <div>
                <span className="count">{rentals.pageNumber === 1 ? 1 : rentals.pageNumber * 10 - 9}-{rentals.count < (10 * rentals.pageNumber) ? (rentals.count) : (10 * rentals.pageNumber)} of {rentals.count}</span>
                <a onClick={() => { prevPage() }} ><span className="left-arrow"><i class="fas fa-chevron-left"></i></span></a>
                <a onClick={() => { nextPage() }}><span className="right-arrow"><i class="fas fa-chevron-right"></i></span></a>
            </div>
        </div>
    </div>);
}


export default Rentals;


