import axios from "axios";
import { useEffect, useState } from "react";
import Modal from 'react-modal';
import { Formik } from 'formik';
import { NotificationContainer, NotificationManager } from 'react-notifications';
import { useDispatch, useSelector } from "react-redux";
import { GetCars,AddCar,DeleteCar,UpdateCar } from "../../../Redux/actions/CarAction";

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
    },
};

const Cars = () => {
    const [modalIsOpen, setIsOpen] = useState(false);
    const [typeEffect, setTypeEffect] = useState('');
    const [selectedObj, setSelectedObj] = useState({});
    const [role,setRole] = useState("");
    const openModal = (type, obj) => {
        setSelectedObj(obj);
        setTypeEffect(type);
        setIsOpen(true);
    }
    
    const cars = useSelector(state => state.Cars);
    const dispatch = useDispatch();


    const afterOpenModal = () => {

    }
    const closeModal = () => {
        setIsOpen(false);
        setSelectedObj({});
    }

    useEffect(() => {
        dispatch(GetCars());
        setRole(JSON.parse(localStorage.getItem("token")).role);
        return () => {
        }
    }, [0]);

    const numPages = (count = 10) => {
        console.log(Math.ceil(cars.count/count));
        return Math.ceil(cars.count/count);
    }
    const prevPage = () => {

        if (cars.pageNumber > 1) {
            var pagenum = cars.pageNumber - 1;
            dispatch(GetCars(10,pagenum));
        }
    }
    const nextPage = () => {
        if (cars.pageNumber < numPages()) {
            var pageNum = cars.pageNumber + 1;
            dispatch(GetCars(10,pageNum));
        }
    }

    const GetSearch = (query) => {
        dispatch(GetCars(10,1,query));
    }
    
    return (
    <div id="carsModal">
        {role == "agent" && <button className="btn btn-mg btn-primary" onClick={() => openModal('ADD', {})}>Create A Car</button>}
         <input placeholder="Search here..." onChange={(e) => GetSearch(e.target.value)} style={{margin: "0 0 0 700px"}}/>
        <br></br>
        <hr></hr>
        <table className="table table-hover">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Car Reg No</th>
                    <th scope="col">Brand</th>
                    <th scope="col">Model</th>
                    <th scope="col">Color</th>
                    <th scope="col">Car Status</th>
                </tr>
            </thead>
            <tbody>

                {cars.list.map((s) => (<tr>
                    <th scope="row">{s.id}</th>
                    <td>{s.carRegNo}</td>
                    <td>{s.brand}</td>
                    <td>{s.model}</td>
                    <td>{s.color}</td>
                    <td>{s.available =="true" ? 'Booked' : "Available"}</td>
                    {role == "agent" && <td><button className="btn btn-outline-success btn-sm" onClick={() => openModal('UPDATE', s)}>
                    <i className="fas fa-pencil-alt fa-sm"></i></button>
                    <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    <button className="btn btn-outline-danger btn-sm" onClick={() => openModal('DELETE', s)}>
                    <i className="fas fa-trash-alt fa-sm"></i></button></td>}

                </tr>)
                )}
            </tbody>
        </table>
        <Modal
            isOpen={modalIsOpen}
            onAfterOpen={afterOpenModal}
            onRequestClose={closeModal}
            style={customStyles}
            contentLabel="Delete Modal"
        >
            {typeEffect === 'DELETE' ?
                (
                    <div>
                        <div className="deletepopup">Are you sure! do you want to delete the car.</div>
                        <hr></hr>
                        <div>
                            <button className="btn btn-outline-primary btn-sm" onClick={() => 
                                {dispatch(DeleteCar(selectedObj.id,() => {setIsOpen(false)}));}}>Sure</button>
                            <span>&nbsp;</span>
                            <button className="btn btn-outline-danger btn-sm" onClick={() => closeModal()}>Close</button>
                        </div>
                    </div>
                ) : <div className="carsModalAdd">
                    <Formik
                        initialValues={typeEffect === 'UPDATE' ? { id:selectedObj.id,carRegNo: selectedObj.carRegNo, brand: selectedObj.brand, model: selectedObj.model, available: selectedObj.available,color: selectedObj.color }  : { carRegNo: '', brand: '', model: '', available: false }}
                        validate={values => {
                            const errors = {};
                            if (!values.brand) {
                                errors.brand = <span style={{color:"red"}}>Required</span>;
                            }
                            if (!values.model) {
                                errors.model = <span style={{color:"red"}}>Required</span>;
                            }
                            if (!values.carRegNo) {
                                errors.carRegNo = <span style={{color:"red"}}>Required</span>;
                            }
                            return errors;
                        }}
                        onSubmit={(values, { setSubmitting }) => {
                            console.log(values);
                            setTimeout(() => {
                                if (typeEffect === 'ADD') {
                                    dispatch(AddCar(values,() => {
                                        setIsOpen(false)
                                        setSelectedObj({});
                                    }));
                                    
                                }
                                else {
                                    dispatch(UpdateCar(values,() => {
                                        setIsOpen(false);
                                        setSelectedObj({});
                                    }));
                                }
                                    
                            }, 400);
                            setSubmitting(false);
                        }}>

                        {({
                            values,
                            errors,
                            touched,
                            handleChange,
                            handleBlur,
                            handleSubmit,
                            isSubmitting,
                        }) => (

                            <form className="carform" onSubmit={handleSubmit}>
                            <div className="form-group row">
                               <div className="form-group col-md-6">
                                <label>Car Reg No</label>   
                                    <input
                                        className="form-control"
                                        type="text"
                                        name="carRegNo"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.carRegNo}
                                    />
                                    {errors.carRegNo && touched.carRegNo && errors.carRegNo}
                                </div>
                                <div className="form-group col-md-6">
                                <label>Brand</label> 
                                    <input
                                        className="form-control"
                                        type="text"
                                        name="brand"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.brand}
                                    />
                                    {errors.brand && touched.brand && errors.brand}
                                </div>
                                </div>
                                <br></br>
                                <div className="form-group row">
                                <div className="form-group col-md-6">
                                <label>Model</label>  
                                    <input
                                       className="form-control"
                                        type="text"
                                        name="model"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.model}
                                    />
                                    {errors.model && touched.model && errors.model}

                                </div>
                                <div className="form-group col-md-6">
                                <label>Availability</label>  
                                    <select
                                        className="form-control"
                                        name='available'
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.available}>
                                        <option value="" label="Select" />
                                        <option type="text" value={true}>Booked</option>
                                        <option type="text" value={false}>Available</option>
                                    </select>
                                    {errors.available && touched.available &&
                                        <div className="input-feedback">
                                            {errors.available}
                                        </div>}
                                </div>
                                </div>
                                <div className="form-group row">
                                <div className="form-group col-md-6">
                                <label>Car Color</label> 
                                <input
                                    className="form-control"
                                    type="text"
                                    name="color"
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                    value={values.color}
                                />
                                {errors.color && touched.color && errors.color}
                                </div>
                                </div>
                                <br></br>
                                <div className="form-group row col-md-12 ms-0">
                                    <button className="btn btn-primary btn-sm btn-block" type="submit" disabled={isSubmitting}>
                                            Submit
                                    </button>    
                                </div> 
                            </form>
                        )}
                    </Formik>
                </div>}
        </Modal>
        <div className="table-bottom">
        <div>
        <span className="count">{cars.pageNumber===1? 1:cars.pageNumber*10-9}-{cars.count < (10*cars.pageNumber)?(cars.count):(10*cars.pageNumber)} of {cars.count}</span>
        <a onClick={() => {prevPage()}} ><span className="left-arrow"><i class="fas fa-chevron-left"></i></span></a>
        <a onClick={() => {nextPage()}}><span className="right-arrow"><i class="fas fa-chevron-right"></i></span></a>
        </div>
        </div>
    </div>);
}


export default Cars;


