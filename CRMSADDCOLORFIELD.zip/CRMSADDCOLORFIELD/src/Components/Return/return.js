import axios from "axios";
import { useEffect, useState } from "react";
import Modal from 'react-modal';
import { Formik } from 'formik';
import { NotificationContainer, NotificationManager } from 'react-notifications';
import { useDispatch, useSelector } from "react-redux";
import { AddReturns, DeleteReturns, GetReturns, UpdateReturns } from './../../Redux/actions/ReturnAction';

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
    },
};

const Returns = () => {
    const [modalIsOpen, setIsOpen] = useState(false);
    const [typeEffect, setTypeEffect] = useState('');
    const [selectedObj, setSelectedObj] = useState({});
    const [role,setRole] = useState("");


    const openModal = (type, obj) => {
        setSelectedObj(obj);
        setTypeEffect(type);
        setIsOpen(true);
    }
    const returns = useSelector(state => state.Returns);
    const dispatch = useDispatch();


    const afterOpenModal = () => {

    }
    const closeModal = () => {
        setIsOpen(false);
        setSelectedObj({});
    }

    useEffect(() => {
        dispatch(GetReturns());
        setRole(JSON.parse(localStorage.getItem("token")).role);
        console.log(returns);
        return () => {
        }
    }, [0]);

    const numPages = (count = 10) => {
        console.log(Math.ceil(returns.count / count));
        return Math.ceil(returns.count / count);
    }
    const prevPage = () => {

        if (returns.pageNumber > 1) {
            var pagenum = returns.pageNumber - 1;
            dispatch(GetReturns(10, pagenum));
        }
    }
    const nextPage = () => {
        if (returns.pageNumber < numPages()) {
            var pageNum = returns.pageNumber + 1;
            dispatch(GetReturns(10, pageNum));
        }
    }
    const GetFinalFee = (intialDays, totalAmt, AddingDays) => {
        if (AddingDays === 0) return totalAmt;
        var a = (totalAmt / intialDays);
        console.log(a);
        return (totalAmt / intialDays) * AddingDays;
    }

    const GetExtraDays = (startDate, EndDate, type) => {
        var date1 = new Date(startDate);
        var date2 = new Date(EndDate);

        // To calculate the time difference of two dates
        var Difference_In_Time = date2.getTime() - date1.getTime();

        // To calculate the no. of days between two dates
        var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);

        if (Difference_In_Days > 0) {
            if (type === 1)
                return Math.floor(Difference_In_Days)
            else return Math.ceil(Difference_In_Days)
        }
        else return 0;
    }

    const GetSearch = (query) => {
        dispatch(GetReturns(10, 1, query));
    }
    
    const returned = true;
    return (<div id="carsModal">
        <input placeholder="Search here..." onChange={(e) => GetSearch(e.target.value)} style={{ margin: "0 0 0 800px" }} />
        <br></br>
        <hr></hr>
        <table className="table table-hover">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Car RegNo</th>
                    <th scope="col">Customer Name</th>
                    <th scope="col">Due Date</th>
                    <th scope="col">Extra Days</th>
                    <th scope="col">Final Fee</th>
                </tr>
            </thead>
            <tbody>

                {returns.list.map((s) => (<tr>
                    <th scope="row">{s.id}</th>
                    <td>{s.cars.carRegNo}</td>
                    <td>{s.customers.customerName}</td>
                    <td>{s.dueDate}</td>
                    <td>{GetExtraDays(s.dueDate, new Date(), 1)}</td>
                    <td>{GetFinalFee(s.pickDate == s.dueDate ? 1 : GetExtraDays(s.pickDate, s.dueDate, 0), s.rentalFee, GetExtraDays(s.pickDate, new Date()))}</td>

                    {role == "agent" &&<td><button className="btn btn-success btn-sm" onClick={() => dispatch(UpdateReturns({...s,returned:true},() => {}))}>
                     Return</button>
                        <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    </td>}

                </tr>)
                )}
            </tbody>
        </table>

        <div className="table-bottom">
            <div>
                <span className="count">{returns.pageNumber === 1 ? 1 : returns.pageNumber * 10 - 9}-{returns.count < (10 * returns.pageNumber) ? (returns.count) : (10 * returns.pageNumber)} of {returns.count}</span>
                <a onClick={() => { prevPage() }} ><span className="left-arrow"><i class="fas fa-chevron-left"></i></span></a>
                <a onClick={() => { nextPage() }}><span className="right-arrow"><i class="fas fa-chevron-right"></i></span></a>
            </div>
        </div>
    </div>);
}


export default Returns;


