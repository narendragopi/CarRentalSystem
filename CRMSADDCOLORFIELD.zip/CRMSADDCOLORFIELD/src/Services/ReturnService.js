import axios from "axios";

export const ReturnService ={

    // GetReturn:async(pageSize = 10,pageNumber =1) =>{
    //     return await  axios.get(`http://localhost:5001/returns?_limit=${pageSize}&_page=${pageNumber}&_order=desc&_sort=id`);
    // },
    // AddReturn:async (returnd) => {
    //    return await axios.post(`http://localhost:5001/returns`,returnd);
    // },
    // UpdateReturn: async (returnd) => {
    //     return await axios.put(`http://localhost:5001/returns/${returnd.id}`,returnd)
    // },
    // DeleteReturn:async (id) => {
    //     return await axios.delete(`http://localhost:5001/returns/${id}`);
    // }
    GetReturn:async(pageSize = 10,pageNumber =1,query='') =>{
        return await  axios.get(`http://localhost:5001/rentals?_limit=${pageSize}&_page=${pageNumber}&_order=desc&_sort=id&_expand=cars&_expand=customers&returned=false&q=${query}`);
    },
    AddReturn:async (returnd) => {
       return await axios.post(`http://localhost:5001/rentals`,returnd);
    },
    UpdateReturn: async (returnd) => {
        return await axios.put(`http://localhost:5001/rentals/${returnd.id}`,returnd)
    },
    DeleteReturn:async (id) => {
        return await axios.delete(`http://localhost:5001/rentals/${id}`);
    }
}