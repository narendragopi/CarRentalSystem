import {
    Navigate,
    useRoutes
  } from 'react-router-dom';

  import { useRoutes } from 'react-router-dom';


  const PublicRoute = ({ children }) => {
    let auth =  JSON.parse(localStorage.getItem('token'));
    
    return auth ? children : <Navigate to="/login" />;
  }

  export default PrivateRoute;