import { CarService } from "../../Services/CarService"
import { APIConstants } from "../constants/APIConstants";
import { NotificationTypes } from "../constants/NotificationConstants";

export const GetCars = (pageSize = 10, pageNumber = 1,query = '') => async (dispatch) => {

    await CarService.GetCars(pageSize, pageNumber,query).then(s => {
        dispatch({
            type: APIConstants.CARS.GET_CARS,
            payload: {
                list: s.data,
                pageSize: pageSize,
                pageNumber: pageNumber,
                count: parseInt(s.headers['x-total-count'])
            }
        })
    }).then(s => {
        console.log(s);
    })
}

export const AddCar = (car, func) => async (dispatch) => {
    await CarService.AddCar(car).then(async s => {
        await CarService.GetCars().then(v => {
            var count = parseInt(v.headers['x-total-count'])
            dispatch({
                type: APIConstants.CARS.ADD_CAR,
                payload: {
                    list: v.data,
                    pageSize: 10,
                    pageNumber: 1,
                    count: count
                }
            })
        });
    }).then(s => {
        dispatch({
            type: NotificationTypes.SUCCESS,
            payload: 'Car added successfully'
        })
    }).finally(() => func());
}

export const UpdateCar = (car, func) => async (dispatch) => {
    await CarService.UpdateCar(car).then(async s => {
        await CarService.GetCars().then(v => {
            var count = parseInt(v.headers['x-total-count'])
            dispatch({
                type: APIConstants.CARS.UPDATE_CAR,
                payload: {
                    list: v.data,
                    pageSize: 10,
                    pageNumber: 1,
                    count: count
                }
            })
        });
    }).then(s => {
        dispatch({
            type: NotificationTypes.INFO,
            payload: 'Car updated successfully'
        })
    }).finally(() => func());

}
export const DeleteCar = (id, func) => async (dispatch) => {
    await CarService.DeleteCar(id).then(async s => {
        await CarService.GetCars().then(v => {
            var count = parseInt(v.headers['x-total-count'])
            dispatch({
                type: APIConstants.CARS.REMOVE_CAR,
                payload: {
                    list: v.data,
                    pageSize: 10,
                    pageNumber: 1,
                    count: count
                }
            })
        })
    }).then(s => {
        dispatch({
            type: NotificationTypes.ERROR,
            payload: 'Car deleted successfully'
        })
    }).finally(() => func());

}


