import { APIConstants } from "../constants/APIConstants";
import { NotificationTypes } from "../constants/NotificationConstants";
import { RentalService } from './../../Services/RentalService';


export const GetRentals = (pageSize = 10, pageNumber = 1,query = '') => async (dispatch) => {

    await RentalService.GetRental(pageSize, pageNumber,query).then(s => {
        dispatch({
            type: APIConstants.RENTALS.GET_RENTALS,
            payload: {
                list: s.data,
                pageSize: pageSize,
                pageNumber: pageNumber,
                count: parseInt(s.headers['x-total-count'])
            }
        })
    }).then(s => {
        console.log(s);
    })
}


export const AddRentals = (rental, func) => async (dispatch) => {

    await RentalService.AddRental(rental).then(async s => {
        await RentalService.GetRental().then(async v => {
            var count = parseInt(v.headers['x-total-count'])

            dispatch({
                type: APIConstants.RENTALS.ADD_RENTALS,
                payload: {
                    list: v.data,
                    pageSize: 10,
                    pageNumber: 1,
                    count: count
                }
            })
        });
    }).then(s => {
        dispatch({
            type: NotificationTypes.SUCCESS,
            payload: 'Rental added successfully'
        })
    }).finally(() => func());

}

export const UpdateRentals = (rental, func) => async (dispatch) => {


    await RentalService.UpdateRental(rental).then(async s => {
        await RentalService.GetRental().then(async v => {
            var count = parseInt(v.headers['x-total-count'])

            dispatch({
                type: APIConstants.RENTALS.UPDATE_RENTALS,
                payload: {
                    list: v.data,
                    pageSize: 10,
                    pageNumber: 1,
                    count: count
                }
            })
        });

    }).then(s => {
        dispatch({
            type: NotificationTypes.INFO,
            payload: 'Rental updated successfully'
        })

    }).finally(() => func());

}
export const DeleteRentals = (id, func) => async (dispatch) => {

    await RentalService.DeleteRental(id).then(async s => {
        await RentalService.GetRental().then(async v => {
            var count = parseInt(v.headers['x-total-count'])

            dispatch({
                type: APIConstants.RENTALS.REMOVE_RENTALS,
                payload: {
                    list: v.data,
                    pageSize: 10,
                    pageNumber: 1,
                    count: count
                }
            })
        });

    }).then(s => {
        dispatch({
            type: NotificationTypes.ERROR,
            payload: 'Rental deleted successfully'
        })

    }).finally(() => func());

}


