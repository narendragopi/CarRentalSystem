import { APIConstants } from '../constants/APIConstants';
const initialState = {

    list: [],
    pageSize: 10,
    pageNumber: 1,
    count:0
}

const ReturnConstants = APIConstants.RETURNS;

function ReturnReducer(returnd = initialState, action) {
    const { type, payload } = action;
    switch (type) {
        case ReturnConstants.GET_RETURNS:
            return payload;

        case ReturnConstants.ADD_RETURNS:
            return payload;

        case ReturnConstants.UPDATE_RETURNS:
            return payload;

        case ReturnConstants.REMOVE_RETURNS: 
            return payload;

        default: return returnd
    }
}

export default ReturnReducer;