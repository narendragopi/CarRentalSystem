import { APIConstants } from '../constants/APIConstants';
const initialState = {

    list: [],
    pageSize: 10,
    pageNumber: 1,
    count:0
}

const CarConstants = APIConstants.CARS;

function Cars (cars = initialState, action) {
    const { type, payload } = action;
    switch (type) {
        case CarConstants.GET_CARS:
            return payload;

        case CarConstants.ADD_CAR:
            return payload;

        case CarConstants.UPDATE_CAR:
            return payload;

        case CarConstants.REMOVE_CAR: 
            return payload;

        default: return cars
    }
}

export default Cars;